const Candidate = require("../models/Candidate");

// Get all candidates
exports.getCandidates = async (req, res) => {
  try {
    const candidates = await Candidate.find();

    res.status(200).json(candidates);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Create candidate
exports.createCandidate = async (req, res) => {
  try {
    const candidate = await Candidate.create(req.body);

    res.status(201).json(candidate);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Delete candidate
exports.deleteCandidate = async (req, res) => {
  try {
    await Candidate.findByIdAndDelete(req.params.id);

    res.status(200).json({
      message: "Candidate deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};