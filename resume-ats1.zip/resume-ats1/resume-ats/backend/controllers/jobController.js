const Job = require("../models/Job");

exports.getJobs = async (req, res) => {
  const jobs = await Job.find();

  res.json(jobs);
};

exports.createJob = async (req, res) => {
  const job = await Job.create(req.body);

  res.json(job);
};

exports.deleteJob = async (req, res) => {
  await Job.findByIdAndDelete(req.params.id);

  res.json({
    message: "Job deleted"
  });
};