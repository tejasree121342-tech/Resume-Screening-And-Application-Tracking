const mongoose = require("mongoose");

const CandidateSchema = new mongoose.Schema(
  {
    name: String,
    email: String,
    skills: [String],
    atsScore: Number,
    status: {
      type: String,
      default: "Applied"
    },
    resume: String
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Candidate", CandidateSchema);