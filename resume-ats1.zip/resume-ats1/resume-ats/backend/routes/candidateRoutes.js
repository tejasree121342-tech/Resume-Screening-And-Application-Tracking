const express = require("express");

const router = express.Router();

const {
  getCandidates,
  createCandidate,
  deleteCandidate
} = require("../controllers/candidateController");

router.get("/", getCandidates);

router.post("/", createCandidate);

router.delete("/:id", deleteCandidate);

module.exports = router;