import { BrowserRouter, Routes, Route } from "react-router-dom";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Jobs from "./pages/Jobs";
import UploadResume from "./pages/UploadResume";
import Candidates from "./pages/Candidates";
import Reports from "./pages/Reports";

function App() {
  return (
    <BrowserRouter>

      <nav>
        <a href="/">Login</a> |{" "}
        <a href="/register">Register</a> |{" "}
        <a href="/dashboard">Dashboard</a> |{" "}
        <a href="/jobs">Jobs</a> |{" "}
        <a href="/upload">Upload</a> |{" "}
        <a href="/candidates">Candidates</a> |{" "}
        <a href="/reports">Reports</a>
      </nav>

      <hr />

      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/jobs" element={<Jobs />} />
        <Route path="/upload" element={<UploadResume />} />
        <Route path="/candidates" element={<Candidates />} />
        <Route path="/reports" element={<Reports />} />
      </Routes>

    </BrowserRouter>
  );
}

export default App;