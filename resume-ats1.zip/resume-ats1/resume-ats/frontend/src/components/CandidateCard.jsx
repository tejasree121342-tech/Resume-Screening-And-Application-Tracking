function CandidateCard({ name, skill }) {
  return (
    <div>
      <h3>{name}</h3>
      <p>Skill: {skill}</p>
    </div>
  );
}

export default CandidateCard;