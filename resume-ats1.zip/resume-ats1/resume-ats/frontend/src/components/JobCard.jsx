function JobCard({ title, company }) {
  return (
    <div>
      <h3>{title}</h3>
      <p>{company}</p>
      <button>Apply</button>
    </div>
  );
}

export default JobCard;