function Navbar() {
  return (
    <nav>
      <h2>Resume ATS</h2>
    </nav>
  );
}

export default Navbar;