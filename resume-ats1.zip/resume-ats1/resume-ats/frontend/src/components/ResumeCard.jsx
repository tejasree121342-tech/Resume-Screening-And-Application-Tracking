function ResumeCard({ fileName }) {
  return (
    <div>
      <p>{fileName}</p>
    </div>
  );
}

export default ResumeCard;