import { Link } from "react-router-dom";

function Sidebar() {
  return (
    <div>
      <h3>Menu</h3>

      <ul>
        <li><Link to="/dashboard">Dashboard</Link></li>
        <li><Link to="/jobs">Jobs</Link></li>
        <li><Link to="/candidates">Candidates</Link></li>
        <li><Link to="/upload">Upload Resume</Link></li>
        <li><Link to="/reports">Reports</Link></li>
      </ul>
    </div>
  );
}

export default Sidebar;