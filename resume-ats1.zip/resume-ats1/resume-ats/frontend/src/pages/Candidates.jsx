import CandidateCard from "../components/CandidateCard";

function Candidates() {
  return (
    <div>
      <h2>Candidates</h2>

      <CandidateCard
        name="John"
        skill="React"
      />
    </div>
  );
}

export default Candidates;