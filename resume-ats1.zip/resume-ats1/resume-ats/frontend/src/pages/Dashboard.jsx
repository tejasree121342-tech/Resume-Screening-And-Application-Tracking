function Dashboard() {
  return (
    <div>
      <h1>ATS Dashboard</h1>
      <p>Welcome to Resume ATS</p>
    </div>
  );
}

export default Dashboard;