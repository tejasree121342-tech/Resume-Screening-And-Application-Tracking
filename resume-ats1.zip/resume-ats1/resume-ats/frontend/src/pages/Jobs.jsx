import JobCard from "../components/JobCard";

function Jobs() {
  return (
    <div>
      <h2>Jobs</h2>

      <JobCard
        title="MERN Developer"
        company="ABC Company"
      />
    </div>
  );
}

export default Jobs;