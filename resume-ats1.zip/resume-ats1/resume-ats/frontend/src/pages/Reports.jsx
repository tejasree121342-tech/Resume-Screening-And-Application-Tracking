function Reports() {
  return (
    <div>
      <h2>Reports</h2>
      <p>Total applications report.</p>
    </div>
  );
}

export default Reports;