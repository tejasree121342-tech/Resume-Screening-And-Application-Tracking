import { useState } from "react";

function UploadResume() {
  const [file, setFile] = useState(null);

  const uploadHandler = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("resume", file);

    try {
      const response = await fetch(
        "http://localhost:5000/api/candidates/upload",
        {
          method: "POST",
          body: formData,
        }
      );

      const data = await response.json();
      alert(data.message);
    } catch (error) {
      console.log(error);
      alert("Upload Failed");
    }
  };

  return (
    <div>
      <h2>Upload Resume</h2>

      <form onSubmit={uploadHandler}>
        <input
          type="file"
          accept=".pdf,.doc,.docx"
          onChange={(e) =>
            setFile(e.target.files[0])
          }
        />

        <br /><br />

        <button type="submit">
          Upload Resume
        </button>
      </form>
    </div>
  );
}

export default UploadResume;