import api from "./api";

export const uploadResume = (data) =>
  api.post("/resume/upload", data);